
typedef struct no *ptno;

struct no {
    int valor;
    int tipo;
    ptno filho;
    ptno irmao;
};

ptno cria_no(int valor, int tipo) {
    ptno novo_no = (ptno)malloc(sizeof(struct no));
    if (!novo_no) {
        return NULL;
    }
    novo_no->valor = valor;
    novo_no->tipo = tipo;
    novo_no->filho = NULL;
    novo_no->irmao = NULL;
    return novo_no;
}

void adiciona_filho(ptno pai, ptno filho) {
    if (!pai || !filho) {
        return;
    }
    filho->irmao = pai->filho;
    pai->filho = filho;
}